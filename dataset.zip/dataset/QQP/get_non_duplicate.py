file = "paws_test1.tsv"

with open(file) as i_f, open("paws_non_duplicate.tsv", 'w') as o_f:
    lines = i_f.read().split('\n')
    for line in lines:
        if line:
            res = eval(line)
            if res['sent_label'] == '0':
                o_f.write(line + '\n')